ANNOYING CLIENT - Launcher 1.0.0 (Minecraft 1.21.11)

1. Extract this zip (right-click > Extract All).
2. Double-click AnnoyingClient.exe.
   If Windows says "Windows protected your PC": click "More info" > "Run anyway".
3. Press PLAY. The first start downloads Minecraft, Java and the client.
   "Via Minecraft Launcher" mode needs the official Minecraft Launcher installed (minecraft.net).
4. In game: Right Shift opens the ClickGUI.

Other files in this zip:
- AnnoyingClient-Installer.exe : only adds Annoying Client to the official Minecraft Launcher (no launcher app).
- annoying-client-1.0.0+mc1.21.11.jar : the mod itself, for manual Fabric installs (.minecraft/mods + Fabric API).
