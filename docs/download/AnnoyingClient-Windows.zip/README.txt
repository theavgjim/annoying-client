ANNOYING CLIENT 1.3.2 (Minecraft 1.21.11)

1. Extract this zip (right-click > Extract All).
2. Double-click AnnoyingClient.exe.
   If Windows says "Windows protected your PC": click "More info" > "Run anyway".
3. Optional: "+ New profile" > "1.21.11 optimized" installs 50 performance and quality mods.
4. Press PLAY. The first start downloads Minecraft, Java and the client.
5. In game: Right Shift opens the ClickGUI (Mod Configs, Wardrobe, Themes and Client tabs).

The launcher updates itself: when a new version is out it shows "Update available" on the Play page.

Other files:
- AnnoyingClient-Installer.exe : only adds Annoying Client to the official Minecraft Launcher.
- annoying-client-1.3.2+mc1.21.11.jar : the mod itself, for manual Fabric installs (needs Fabric API).
